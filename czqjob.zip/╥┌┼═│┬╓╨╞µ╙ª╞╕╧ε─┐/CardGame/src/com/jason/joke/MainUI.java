package com.jason.joke;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;

import com.google.common.eventbus.Subscribe;
/**
 * @author czq  
 *  游戏 主程序 ，主界面
 *
 */
public class MainUI extends JFrame {
	private static Logger logger = Logger.getLogger(JokeGame.class.getSimpleName());
	private JTextArea outputTextArea;

	public MainUI() {
		JokeGame.getInstance().getEventBus().register(this);
		Container container = getContentPane();
		setTitle(" Playing Card Game");
		container.setLayout(new BorderLayout());
		JButton startButton = new JButton("Start");
		outputTextArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(outputTextArea);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		container.add("South", startButton);
		container.add("Center", scrollPane);
		startButton.addActionListener(new ActionListener() { // 为确定按钮添加监听事件
			public void actionPerformed(ActionEvent arg0) {
				new Thread() {
					@Override
					public void run() {
						JokeGame jokeGame = JokeGame.getInstance();
						jokeGame.iniGame();
						jokeGame.start();
					}
				}.start();

			}
		});
	}

	@Subscribe
	public void lister(String message) {
		logger.debug("lister " + message);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				outputTextArea.append(message + "\r\n");
				outputTextArea.setCaretPosition(outputTextArea.getText().length());
			}
		});
	}

	public static void main(String[] args) {
		MainUI mainUI = new MainUI();
		mainUI.setLocationRelativeTo(null);// 窗体居中显示
		mainUI.setSize(400, 400);
		mainUI.setVisible(true);
	}
}
