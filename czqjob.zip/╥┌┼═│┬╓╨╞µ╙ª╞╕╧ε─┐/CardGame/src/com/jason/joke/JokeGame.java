package com.jason.joke;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.google.common.eventbus.EventBus;

/**
 * @author czq  
 *  游戏 主逻辑 ，开始程序后 ，一个线程负责发牌，另外一个线程负责 检查 游戏运行是否 有人赢了，结束。
 *
 */
public class JokeGame {
	private static JokeGame instance = new JokeGame();
	private PlayingCards playingCards = new PlayingCards();
	private List<Player> players = Collections.synchronizedList(new ArrayList<Player>());
	private EventBus eventBus = new EventBus();
	private String END = "0"; // 通知线程 ，游戏已经结束
	private String START = "1"; // 通知线程开始处理
	public static int WIN_POINT = 50;
	private BlockingQueue<String> sendCardBlockingQueue = new ArrayBlockingQueue<String>(1);
	private BlockingQueue<String> checkWinBlockingQueue = new ArrayBlockingQueue<String>(1);
	private static Logger logger = Logger.getLogger(JokeGame.class.getSimpleName());

	private JokeGame() {
		super();
	}

	public EventBus getEventBus() {
		return eventBus;
	}

	public static JokeGame getInstance() {
		return instance;
	}

	public void iniGame() {
		players.clear();
		players.add(new Player());
		players.add(new Player());
		players.add(new Player());
		eventBus.post(" start game ------------------------------------------");
	}

	public void start() {
		playingCards.iniCard();
		sendCardBlockingQueue.clear();
		try {
			sendCardBlockingQueue.put(START);
		} catch (InterruptedException e) {
			logger.error(" blockingQueue InterruptedException ", e);
		}
		new SendCardThread().start();
		new CheckGameWinThread().start();
	}

	public class SendCardThread extends Thread {
		@Override
		public void run() {
			try {
				out: while (true) {
					Object command = sendCardBlockingQueue.take();
					if (END.equals(command)) {
						String message = "Thread1 stop when palyer win  ";
						eventBus.post(message);
						break out;
					}
					for (int i = 0; i < players.size(); i++) {
						Card card = playingCards.popCard();
						// 牌肯定发光前就会结束。目前不需要处理发光逻辑。
						Player nextPlayer = players.get(i);
						nextPlayer.addCard(card);
						String message = "Thread1   player " + i + " get card " + card.getName();
						eventBus.post(message);
					}
					checkWinBlockingQueue.put(START);
				}
			} catch (InterruptedException e) {
				logger.error(" blockingQueue InterruptedException ", e);
			}
		}
	}

	public class CheckGameWinThread extends Thread {
		@Override
		public void run() {
			try {
				out: while (true) {
					Object command = checkWinBlockingQueue.take();
					for (int i = 0; i < players.size(); i++) {
						Player nextPlayer = players.get(i);
						if (nextPlayer.checkWin(i)) {
							String message = "Thread2  player " + i + " win ";
							eventBus.post(message);
							sendCardBlockingQueue.put(END);
							break out;
						}
					}
					sendCardBlockingQueue.put(START);
				}
			} catch (InterruptedException e) {
				logger.error(" blockingQueue InterruptedException ", e);
			}
		}
	}

}
