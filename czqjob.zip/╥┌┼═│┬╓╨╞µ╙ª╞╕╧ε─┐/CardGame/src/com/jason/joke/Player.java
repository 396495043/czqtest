package com.jason.joke;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
/**
 * @author czq  
 *  游戏 玩家
 *
 */
public class Player {
	private List<Card> cards =  Collections.synchronizedList(new ArrayList<Card>());
	public void addCard(Card card) {
		cards.add(card);
	}

	public boolean checkWin(int userIndex) {
		int sum = 0;
		for (Card card : cards) {
			sum += card.getPoint();
		}
		String message = "Thread2 player " + userIndex + " total point  " + sum;
		JokeGame.getInstance().getEventBus().post(message);
		boolean win = sum > JokeGame.WIN_POINT;
		return win;
	}
}
