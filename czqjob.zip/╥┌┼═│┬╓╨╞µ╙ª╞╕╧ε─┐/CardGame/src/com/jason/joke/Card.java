package com.jason.joke;
/**
 * @author czq  
 *  一张扑克牌
 *
 */
public class Card {
	private int point;
	private int type;

	public Card(int point, int type) {
		super();
		this.point = point;
		this.type = type;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getName() {
		return " point:" + point + " type:" + type;
	}
}
