package com.jason.joke;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * @author czq  
 *  整副扑克牌
 *
 */
public class PlayingCards {

	private List<Card> cards = new ArrayList<Card>();

	public Card popCard() {
		if (cards.size() == 0) {
			return null ;
		}
		return cards.remove(0);
	}

	public void iniCard() {
		cards.clear();
		int typeCount = 4;
		int pointCount = 13;
		for (int i = 0; i < typeCount; i++) {
			for (int j = 1; j < pointCount + 1; j++) {
				Card card = new Card(j, i);
				cards.add(card);
			}
		}
		cards.add(new Card(20, 0));
		cards.add(new Card(20, 1));
		Collections.shuffle(cards); // 打乱牌
	}
}
